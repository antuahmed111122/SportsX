package com.sportwave.app.ui.common

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFmt = ThreadLocal.withInitial { SimpleDateFormat("EEE, d MMM", Locale.getDefault()) }
private val timeFmt = ThreadLocal.withInitial { SimpleDateFormat("h:mm a", Locale.getDefault()) }

fun formatMatchDate(millis: Long): String = dateFmt.get()!!.format(Date(millis))
fun formatMatchTime(millis: Long): String = timeFmt.get()!!.format(Date(millis))
