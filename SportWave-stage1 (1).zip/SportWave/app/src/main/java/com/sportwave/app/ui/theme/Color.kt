package com.sportwave.app.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val Navy900 = Color(0xFF050A18)
val Navy800 = Color(0xFF0A1226)
val Navy700 = Color(0xFF111B38)
val Navy600 = Color(0xFF1A274D)

val WaveCyan = Color(0xFF22D3EE)
val WaveBlue = Color(0xFF3B82F6)
val LiveRed = Color(0xFFFF3B4E)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9AA6C4)
