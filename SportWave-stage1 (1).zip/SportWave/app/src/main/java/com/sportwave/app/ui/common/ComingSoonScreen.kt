package com.sportwave.app.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.sportwave.app.ui.theme.Navy900
import com.sportwave.app.ui.theme.TextPrimary
import com.sportwave.app.ui.theme.TextSecondary

/** Temporary screen for tabs that are built in later stages. Replaced, not extended. */
@Composable
fun ComingSoonScreen(title: String, builtInStage: Int) {
    Column(
        modifier = Modifier.fillMaxSize().background(Navy900),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Text("Built in Stage $builtInStage", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
    }
}
