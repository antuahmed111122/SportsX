package com.sportwave.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.ui.graphics.vector.ImageVector

enum class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Filled.Home),
    FOOTBALL("football", "Football", Icons.Filled.SportsSoccer),
    CRICKET("cricket", "Cricket", Icons.Filled.SportsCricket),
    LIVE("live", "Live", Icons.Filled.LiveTv),
    SETTINGS("settings", "Settings", Icons.Filled.Settings)
}
