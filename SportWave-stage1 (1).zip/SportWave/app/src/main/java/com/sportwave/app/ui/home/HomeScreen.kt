package com.sportwave.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.sportwave.app.data.model.Match
import com.sportwave.app.data.model.MatchStatus
import com.sportwave.app.data.model.Sport
import com.sportwave.app.data.sample.SampleData
import com.sportwave.app.ui.components.FeaturedCard
import com.sportwave.app.ui.components.MatchCard
import com.sportwave.app.ui.components.SectionHeader
import com.sportwave.app.ui.theme.Black
import com.sportwave.app.ui.theme.Navy800
import com.sportwave.app.ui.theme.TextPrimary
import com.sportwave.app.ui.theme.WaveCyan

@Composable
fun HomeScreen(
    onMatchClick: (Match) -> Unit = {},
    onSearchClick: () -> Unit = {}
) {
    val matches = remember { SampleData.matches() }
    val featured = remember(matches) { matches.filter { it.status == MatchStatus.LIVE && it.hasStream } }
    val live = remember(matches) { matches.filter { it.status == MatchStatus.LIVE } }
    val upcoming = remember(matches) {
        matches.filter { it.status == MatchStatus.UPCOMING }.sortedBy { it.startTimeMillis }
    }
    val football = remember(matches) { matches.filter { it.sport == Sport.FOOTBALL } }
    val cricket = remember(matches) { matches.filter { it.sport == Sport.CRICKET } }
    val recent = remember(matches) { matches.sortedByDescending { it.addedAtMillis }.take(6) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy800, Black))),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item(key = "header") { HomeHeader(onSearchClick) }

        if (featured.isNotEmpty()) {
            item(key = "featured") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader("Featured Live Matches")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(featured, key = { it.id }) { match ->
                            FeaturedCard(
                                match = match,
                                onClick = { onMatchClick(match) },
                                modifier = Modifier.width(320.dp).height(190.dp)
                            )
                        }
                    }
                }
            }
        }

        matchSection("Live Now", live, onMatchClick)
        matchSection("Upcoming Matches", upcoming, onMatchClick)
        matchSection("Football", football, onMatchClick)
        matchSection("Cricket", cricket, onMatchClick)
        matchSection("Recently Added", recent, onMatchClick)
    }
}

private fun LazyListScope.matchSection(
    title: String,
    matches: List<Match>,
    onMatchClick: (Match) -> Unit
) {
    if (matches.isEmpty()) return
    item(key = "section-$title") {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeader(title)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(matches, key = { "$title-${it.id}" }) { match ->
                    MatchCard(
                        match = match,
                        onClick = { onMatchClick(match) },
                        onWatch = { onMatchClick(match) },
                        modifier = Modifier.width(300.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(onSearchClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.PlayArrow,
            contentDescription = null,
            tint = Black,
            modifier = Modifier
                .size(34.dp)
                .background(WaveCyan, RoundedCornerShape(10.dp))
                .padding(4.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = "SportWave",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSearchClick) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextPrimary)
        }
    }
}
