package com.sportwave.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sportwave.app.ui.common.ComingSoonScreen
import com.sportwave.app.ui.home.HomeScreen
import com.sportwave.app.ui.navigation.TopLevelDestination
import com.sportwave.app.ui.theme.Black
import com.sportwave.app.ui.theme.Navy600
import com.sportwave.app.ui.theme.Navy800
import com.sportwave.app.ui.theme.TextSecondary
import com.sportwave.app.ui.theme.WaveCyan

@Composable
fun SportWaveApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        containerColor = Black,
        bottomBar = {
            NavigationBar(containerColor = Navy800) {
                TopLevelDestination.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = WaveCyan,
                            selectedTextColor = WaveCyan,
                            indicatorColor = Navy600,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = TopLevelDestination.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(TopLevelDestination.HOME.route) { HomeScreen() }
            composable(TopLevelDestination.FOOTBALL.route) { ComingSoonScreen("Football", 3) }
            composable(TopLevelDestination.CRICKET.route) { ComingSoonScreen("Cricket", 3) }
            composable(TopLevelDestination.LIVE.route) { ComingSoonScreen("Live", 3) }
            composable(TopLevelDestination.SETTINGS.route) { ComingSoonScreen("Settings", 6) }
        }
    }
}
