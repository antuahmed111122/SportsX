package com.sportwave.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sportwave.app.data.model.Match
import com.sportwave.app.data.model.MatchStatus
import com.sportwave.app.data.model.Team
import com.sportwave.app.ui.common.formatMatchDate
import com.sportwave.app.ui.common.formatMatchTime
import com.sportwave.app.ui.theme.Navy700
import com.sportwave.app.ui.theme.TextPrimary
import com.sportwave.app.ui.theme.TextSecondary
import com.sportwave.app.ui.theme.WaveCyan

@Composable
fun MatchCard(
    match: Match,
    onClick: () -> Unit,
    onWatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Navy700)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = match.competition,
                    style = MaterialTheme.typography.labelLarge,
                    color = WaveCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                if (match.status == MatchStatus.LIVE) {
                    LiveBadge()
                } else {
                    Text(
                        text = formatMatchDate(match.startTimeMillis),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TeamColumn(match.home, match.homeScore, Modifier.weight(1f))
                Column(
                    modifier = Modifier.weight(0.8f).padding(top = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val center = when (match.status) {
                        MatchStatus.UPCOMING -> formatMatchTime(match.startTimeMillis)
                        else -> match.statusText.orEmpty()
                    }
                    Text(
                        text = if (match.status == MatchStatus.UPCOMING) "VS" else "—",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = center,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }
                TeamColumn(match.away, match.awayScore, Modifier.weight(1f))
            }

            if (match.hasStream && match.status != MatchStatus.FINISHED) {
                Button(
                    onClick = onWatch,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WaveCyan, contentColor = androidx.compose.ui.graphics.Color.Black)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("WATCH LIVE", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun TeamColumn(team: Team, score: String?, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        TeamLogo(team)
        Spacer(Modifier.height(8.dp))
        Text(
            text = team.name,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (!score.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = score,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
        }
    }
}
