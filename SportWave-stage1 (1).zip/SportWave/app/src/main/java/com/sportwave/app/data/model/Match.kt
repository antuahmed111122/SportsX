package com.sportwave.app.data.model

enum class Sport { FOOTBALL, CRICKET }

enum class MatchStatus { LIVE, UPCOMING, FINISHED }

data class Team(
    val name: String,
    val shortName: String,
    /** Remote logo URL. Image loading is wired in Stage 3; until then a colored badge is drawn. */
    val logoUrl: String? = null,
    val colorHex: Long = 0xFF3B82F6
)

data class Match(
    val id: String,
    val sport: Sport,
    val competition: String,
    val home: Team,
    val away: Team,
    val status: MatchStatus,
    val startTimeMillis: Long,
    val homeScore: String? = null,
    val awayScore: String? = null,
    /** e.g. "67'" for football or "Over 18.2" for cricket. */
    val statusText: String? = null,
    /** Only ever set to an officially licensed stream or one you have permission to distribute. */
    val streamUrl: String? = null,
    val addedAtMillis: Long = 0L
) {
    val hasStream: Boolean get() = !streamUrl.isNullOrBlank()
}
