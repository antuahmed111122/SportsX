package com.sportwave.app.data.sample

import com.sportwave.app.data.model.Match
import com.sportwave.app.data.model.MatchStatus
import com.sportwave.app.data.model.Sport
import com.sportwave.app.data.model.Team

/**
 * Development-only sample data. In Stage 4 this is replaced by Firestore.
 * The stream URL is a public HLS test stream, used only as a development placeholder.
 */
object SampleData {
    private const val TEST_HLS = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    private const val HOUR = 3_600_000L
    private const val DAY = 24 * HOUR

    private val arsenal = Team("Arsenal", "ARS", colorHex = 0xFFE11D2E)
    private val chelsea = Team("Chelsea", "CHE", colorHex = 0xFF1D4ED8)
    private val realMadrid = Team("Real Madrid", "RMA", colorHex = 0xFFE5E7EB)
    private val barcelona = Team("Barcelona", "BAR", colorHex = 0xFF7C2D92)
    private val inter = Team("Inter", "INT", colorHex = 0xFF1E40AF)
    private val milan = Team("AC Milan", "MIL", colorHex = 0xFFB91C1C)
    private val bayern = Team("Bayern Munich", "BAY", colorHex = 0xFFDC2626)
    private val dortmund = Team("Dortmund", "BVB", colorHex = 0xFFEAB308)
    private val psg = Team("Paris SG", "PSG", colorHex = 0xFF1E3A8A)
    private val marseille = Team("Marseille", "OM", colorHex = 0xFF0EA5E9)
    private val abahani = Team("Abahani", "ABA", colorHex = 0xFF38BDF8)
    private val mohammedan = Team("Mohammedan", "MSC", colorHex = 0xFF111827)

    private val bangladesh = Team("Bangladesh", "BAN", colorHex = 0xFF15803D)
    private val india = Team("India", "IND", colorHex = 0xFF2563EB)
    private val pakistan = Team("Pakistan", "PAK", colorHex = 0xFF166534)
    private val australia = Team("Australia", "AUS", colorHex = 0xFFCA8A04)
    private val england = Team("England", "ENG", colorHex = 0xFF1E40AF)
    private val mi = Team("Mumbai Indians", "MI", colorHex = 0xFF1D4ED8)
    private val csk = Team("Chennai Super Kings", "CSK", colorHex = 0xFFEAB308)
    private val comilla = Team("Comilla Victorians", "COV", colorHex = 0xFFDC2626)
    private val rangpur = Team("Rangpur Riders", "RAN", colorHex = 0xFFB91C1C)

    fun matches(now: Long = System.currentTimeMillis()): List<Match> = listOf(
        Match("f1", Sport.FOOTBALL, "Premier League", arsenal, chelsea, MatchStatus.LIVE,
            now - HOUR, "2", "1", "67'", TEST_HLS, now - 2 * DAY),
        Match("f2", Sport.FOOTBALL, "La Liga", realMadrid, barcelona, MatchStatus.LIVE,
            now - HOUR / 2, "0", "0", "31'", TEST_HLS, now - 3 * DAY),
        Match("f3", Sport.FOOTBALL, "Serie A", inter, milan, MatchStatus.UPCOMING,
            now + 3 * HOUR, addedAtMillis = now - DAY),
        Match("f4", Sport.FOOTBALL, "Bundesliga", bayern, dortmund, MatchStatus.UPCOMING,
            now + DAY, streamUrl = TEST_HLS, addedAtMillis = now - HOUR),
        Match("f5", Sport.FOOTBALL, "Ligue 1", psg, marseille, MatchStatus.UPCOMING,
            now + 2 * DAY, addedAtMillis = now - 5 * HOUR),
        Match("f6", Sport.FOOTBALL, "Bangladesh Premier League", abahani, mohammedan, MatchStatus.UPCOMING,
            now + 5 * HOUR, addedAtMillis = now - 2 * HOUR),
        Match("c1", Sport.CRICKET, "T20 International", bangladesh, india, MatchStatus.LIVE,
            now - 2 * HOUR, "142/4", "-", "Over 16.3", TEST_HLS, now - 4 * HOUR),
        Match("c2", Sport.CRICKET, "Test Series", australia, england, MatchStatus.LIVE,
            now - 6 * HOUR, "312/5", "-", "Day 2", null, now - 6 * HOUR),
        Match("c3", Sport.CRICKET, "IPL", mi, csk, MatchStatus.UPCOMING,
            now + 6 * HOUR, streamUrl = TEST_HLS, addedAtMillis = now - 30 * 60_000L),
        Match("c4", Sport.CRICKET, "BPL", comilla, rangpur, MatchStatus.UPCOMING,
            now + 2 * DAY, addedAtMillis = now - 3 * HOUR),
        Match("c5", Sport.CRICKET, "ODI", pakistan, bangladesh, MatchStatus.FINISHED,
            now - DAY, "276/8", "270/10", "Pakistan won by 6 runs", null, now - DAY)
    )
}
