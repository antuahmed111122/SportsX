package com.sportwave.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sportwave.app.data.model.Match
import com.sportwave.app.data.model.MatchStatus
import com.sportwave.app.ui.theme.Navy900
import com.sportwave.app.ui.theme.TextPrimary
import com.sportwave.app.ui.theme.TextSecondary
import com.sportwave.app.ui.theme.WaveCyan

@Composable
fun FeaturedCard(
    match: Match,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val homeColor = Color(match.home.colorHex)
    val awayColor = Color(match.away.colorHex)
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Navy900)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(homeColor.copy(alpha = 0.55f), Navy900, awayColor.copy(alpha = 0.55f))
                    )
                )
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (match.status == MatchStatus.LIVE) {
                        LiveBadge()
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(
                        match.competition,
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    Modifier.fillMaxSize().weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TeamLogo(match.home, size = 60.dp)
                    Text(
                        text = if (match.homeScore != null && match.status != MatchStatus.UPCOMING)
                            "${match.homeScore}  -  ${match.awayScore}" else "VS",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    TeamLogo(match.away, size = 60.dp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${match.home.name} vs ${match.away.name}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (match.hasStream) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Stream available", tint = WaveCyan)
                    }
                }
            }
        }
    }
}
