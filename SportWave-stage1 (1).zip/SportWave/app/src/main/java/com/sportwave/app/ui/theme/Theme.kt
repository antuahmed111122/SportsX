package com.sportwave.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SportWaveColors = darkColorScheme(
    primary = WaveCyan,
    onPrimary = Black,
    secondary = WaveBlue,
    onSecondary = TextPrimary,
    background = Navy900,
    onBackground = TextPrimary,
    surface = Navy800,
    onSurface = TextPrimary,
    surfaceVariant = Navy700,
    onSurfaceVariant = TextSecondary,
    error = LiveRed
)

@Composable
fun SportWaveTheme(content: @Composable () -> Unit) {
    // SportWave is dark-first. A user-controlled light/dark switch arrives with Settings (Stage 6).
    MaterialTheme(
        colorScheme = SportWaveColors,
        typography = SportWaveTypography,
        content = content
    )
}
