package com.sportwave.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sportwave.app.data.model.Team
import com.sportwave.app.ui.theme.TextPrimary

/** Placeholder crest drawn from team color + short name. Real logos (Coil) are added in Stage 3. */
@Composable
fun TeamLogo(team: Team, size: Dp = 52.dp, modifier: Modifier = Modifier) {
    val base = Color(team.colorHex)
    Box(
        modifier = modifier
            .size(size)
            .background(Brush.linearGradient(listOf(base, base.copy(alpha = 0.55f))), CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = team.shortName,
            style = MaterialTheme.typography.labelSmall,
            color = if (team.colorHex == 0xFFE5E7EB || team.colorHex == 0xFFEAB308) Color.Black else TextPrimary
        )
    }
}
