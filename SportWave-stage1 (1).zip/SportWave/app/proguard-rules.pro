# Stage 1: no custom rules yet. Retrofit/Media3/Firebase rules are added in later stages.
